﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solsys
{
    class Program
    {
        static void Main(string[] args)
        {
            var bolygok = new List<Bolygo>();

            foreach (var item in File.ReadAllLines(@"../../src/solsys.txt"))
            {
                bolygok.Add(new Bolygo(item));
            }

            Console.WriteLine("3. feladat");

            Console.WriteLine("3.1");
            double db = 0;

            for (int i = 0; i < bolygok.Count; i++)
            {
                db++;
            }

            Console.WriteLine($"{db} bolygó van a naprendszerben");

            //Sum = bolygok.Sum(b => b.bolygoNev.Length);

            //Console.WriteLine($"{Sum} bolygó van a naprendszerben");
            

            Console.WriteLine("3.2");
            double atlag;

            atlag = bolygok.Average(b => b.bolygoHoldSzam);
            Console.WriteLine($"a naprendszerben egy bolygónak átlagosan{atlag} holdja van");

            Console.WriteLine("3.3");

            double max = bolygok.Max(b => b.BolygoTerfogat);

            Console.WriteLine($"{max}");

            Console.WriteLine("3.4");

            Console.WriteLine("3.5");

            Console.Write("Írj be egy egész számot: ");
            int szam = Convert.ToInt32(Console.ReadLine());
            string szamoltBolygok;
            for (int i = 0; i < bolygok.Count; i++)
            {

            if (szam > 10)
            {
                    szamoltBolygok = bolygok[i].bolygoNev;
                    Console.WriteLine($"a köveztkező bolygóknak vab{szamoltBolygok}");
            }

            }
            



        }
    }
}
