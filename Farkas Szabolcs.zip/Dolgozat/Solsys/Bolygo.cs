﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solsys
{
    class Bolygo
    {
        public string bolygoNev { get; set; }
        public int bolygoHoldSzam { get; set; }
        public int BolygoTerfogat { get; set; }

        public Bolygo(string sor) 
        {
            List<string> atmeneti = sor.Split(';').ToList();
                bolygoNev = atmeneti[0];
                bolygoHoldSzam = int.Parse(atmeneti[1]);
                BolygoTerfogat = int.Parse(atmeneti[2]);
        }
    }
}
